package es.uma.informatica.sii.pr2025rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpedicionesApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExpedicionesApplication.class, args);
    }

}
