package es.uma.informatica.sii.pr2025rest.excepciones;

public class ExpedicionConEquiposException extends RuntimeException {
}
