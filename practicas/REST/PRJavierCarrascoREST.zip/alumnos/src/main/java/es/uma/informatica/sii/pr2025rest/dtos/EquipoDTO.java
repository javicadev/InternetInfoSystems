package es.uma.informatica.sii.pr2025rest.dtos;

import lombok.Data;

@Data
public class EquipoDTO {
    private Long id;
    private String nombre;
    private String especialidad;

}
